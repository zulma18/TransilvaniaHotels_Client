﻿using Microsoft.Data.SqlClient;
using TransilvaniaHotels_Clients.Models;

namespace TransilvaniaHotels_Clients.Data
{
    public class ClientData
    {
        private readonly string _connectionString;

        private readonly IConfiguration _configuration;

        public ClientData(IConfiguration configuration)
        {
            _configuration = configuration;

            /*Mandar a llamar la conexon*/
            _connectionString = _configuration.GetConnectionString("default"); /*nombre de la conexion del arh "appsettings.json" */
        }

        /*Metodo para acceder a la conx*/
        public SqlConnection GetConnection() => new SqlConnection(_connectionString);

    }
}
